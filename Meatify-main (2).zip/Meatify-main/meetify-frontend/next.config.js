/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    turbo: false
  }
};

module.exports = nextConfig;
